# import json

# def handler(event, context):
#   print('received event:')
#   print(event)
  
#   return {
#       'statusCode': 200,
#       'headers': {
#           'Access-Control-Allow-Headers': '*',
#           'Access-Control-Allow-Origin': '*',
#           'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
#       },
#       'body': json.dumps('Hello from your new Amplify Python lambda!')
#   }

## NOTE: to use Python in this project you have to navigate to the project directory and use virtualenv (I called in my computer capstoneenv)
# -> in this virtual environment are all the packages needed installed

from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from flask_cors import CORS, cross_origin
import awsgi

app = Flask(__name__)
CORS(app)

@app.route("/sendphoto", methods = ['POST'])
@cross_origin() # This decorator can be used to allow specific origins, methods, etc.
def upload_file():
    #Check if a photo is part of the request
    if 'photo' in request.files:
        file = request.files['photo']
        filename = secure_filename(file.filename)
        # Process the file (save or send to SageMaker etc.)
        # Since the SageMaker part is handled elsewhere, we assume it is processed.
        # Return the predefined JSON response as a success indicator.
        response = {
            "composition": {
                "polyester": 30,
                "elastane": 10,
                "rayon": 40,
                "cotton": 20
            },
            "sample_id": "6509"
        }

        return jsonify(response), 200

    else:
        return jsonify({"error": "No photo uploaded"}), 400

def lambda_handler(event, context):
    return awsgi.response(app, event, context)